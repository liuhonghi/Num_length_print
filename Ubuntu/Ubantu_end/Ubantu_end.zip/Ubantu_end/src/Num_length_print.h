//
//  Num_length_print.h
//  Ubuntu
//
//  Created by HiLau on 2023/6/8.
//

#include <stdio.h>


void* Num_length_print(void* args);

