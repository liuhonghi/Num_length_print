#include <stdio.h>

void num_reverse_print(int num,char* result);