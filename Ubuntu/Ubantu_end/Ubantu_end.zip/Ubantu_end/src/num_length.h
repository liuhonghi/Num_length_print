#include <stdio.h>

int num_length(int num);